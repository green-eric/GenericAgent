# R33 | BullishForMonitoring SSE_BROADCAST 端到端集成测试

## 任务
为 BullishForMonitoring 编写端到端集成测试，覆盖 SSE 数据流全链路：
  quote_streamer → EventBus → MarketDataConsumer → SSE_BROADCAST → 前端接收

## 新建文件
`tests/test_sse_broadcast.py` — 9 个测试，4 个测试类

## 测试清单

### TestSSEBroadcastChain（3个）— 核心链路
| 测试 | 内容 |
|------|------|
| test_market_data_triggers_sse_broadcast | market_data 事件 → Consumer 自动发布 SSE_BROADCAST |
| test_news_triggers_sse_broadcast | news 事件 → Consumer 自动发布 SSE_BROADCAST |
| test_pipeline_summary_triggers_sse_broadcast | pipeline_summary 事件 → Consumer 转发 SSE_BROADCAST |

### TestSSEBroadcastContent（3个）— 数据完整性
| 测试 | 内容 |
|------|------|
| test_sse_broadcast_preserves_all_market_fields | SSE_BROADCAST 保留行情数据所有字段 |
| test_sse_broadcast_source_tracking | SSE_BROADCAST 记录事件来源 (source) |
| test_sse_broadcast_data_wrapper_format | SSE_BROADCAST data 包含 type/payload/source |

### TestSSEBroadcastFromProducer（1个）— 生产者链路
| 测试 | 内容 |
|------|------|
| test_signal_producer_to_sse | SignalProducer 发布 SIGNAL 事件，可被 SSE_BROADCAST 订阅者接收 |

### TestSSEBroadcastBackpressure（2个）— 背压控制
| 测试 | 内容 |
|------|------|
| test_sse_broadcast_queue_full_dropped | 队列满时丢弃事件，_dropped 计数正确 |
| test_sse_broadcast_high_throughput | 100 条事件高吞吐，无丢失 |

## 运行结果
```
Ran 9 tests in 8.386s — OK ✅
```

## 技术发现
- **pytest 超时问题**: BfM 项目的 pytest 会超时（可能 conftest.py 的 autouse fixture 或模块导入副作用），改用 `python -m unittest` 正常运行
- **EventBus.stop() 残留队列**: 停止后队列可能有残留事件（已知行为，不影响测试）
- **Consumer SSE_BROADCAST 转发**: Consumer 正确将 market_data/news/pipeline_summary 三种事件类型都转发为 SSE_BROADCAST

## 已修改的文件
- `tests/test_sse_broadcast.py`: 新建，9 个测试

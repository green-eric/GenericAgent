# R34 | AnnualScorer 覆盖缺口补全测试

## 任务
完善 AnnualScorer 项目文档和测试 — 针对 coverage 报告中覆盖不足的模块补充测试

## 背景
- 原有 246 测试全部通过，90% 总覆盖率
- 主要覆盖缺口: utils.py 44%, annual_scorer.py 57%, fetcher.py 75%, industry.py 74%

## 新建文件
`tests/test_coverage_gap.py` — 36 个测试，5 个测试类

### 覆盖率提升
| 模块 | 补前 | 补后 | 提升 |
|------|------|------|------|
| utils.py | 44% | **95%** | +51% |
| annual_scorer.py | 57% | 57% | — |
| **总计** | **90%** | **93%** | **+3%** |

### 测试清单

#### TestUtilsLogger (6个) — logger 工具函数
| 测试 | 覆盖 |
|------|------|
| test_get_logger_singleton | get_logger 单例模式 |
| test_get_logger_quiet_mode | quiet=True 只有 FileHandler |
| test_get_logger_normal_has_console | quiet=False 有 FileHandler+StreamHandler |
| test_reset_logger_clears_handlers | reset_logger 清除 handlers |
| test_cleanup_old_logs | _cleanup_old_logs 不报错 |
| test_get_logger_creates_log_file | 创建日志文件 |

#### TestUtilsToken (7个) — Token 加载
| 测试 | 覆盖 |
|------|------|
| test_load_token_plain_text | 纯文本格式 |
| test_load_token_json_format | JSON 格式 |
| test_load_token_json_with_whitespace | JSON token 含空格 |
| test_load_token_file_not_found | 文件不存在 |
| test_load_token_empty_file | 空文件 |
| test_load_token_json_empty_token_field | JSON token 字段为空 |
| test_load_token_json_invalid_falls_back | 无效 JSON 回退 |

#### TestUtilsParseNum (10个) — 数字解析
| 测试 | 覆盖 |
|------|------|
| test_parse_num_percentage | 百分比解析 |
| test_parse_num_plain_number | 普通数字 |
| test_parse_num_none_and_empty | None/空字符串 |
| test_parse_num_no_digits | 无数字字符串 |
| test_parse_num_from_line_with_units | 带单位数值(万亿/亿/万/千/元) |
| test_parse_num_from_line_none_and_empty | 行解析空值 |
| test_parse_num_from_line_no_unit | 无单位返回 None |
| test_year_of_date_normal | 正常日期 |
| test_year_of_date_none/empty/invalid | 边界日期 |

#### TestUtilsThreadSession (3个) — 线程安全 Session
| 测试 | 覆盖 |
|------|------|
| test_get_thread_session_returns_session | 返回 requests.Session |
| test_session_has_adapters | 有 http/https adapter |
| test_get_thread_session_thread_local | 线程隔离 |

#### TestAnnualScorerLoadStockList (8个) — 股票列表加载
| 测试 | 覆盖 |
|------|------|
| test_load_stock_list_space_separated | 空格分隔 |
| test_load_stock_list_comma_separated | 逗号分隔 |
| test_load_stock_list_tab_separated | Tab 分隔 |
| test_load_stock_list_skip_empty_lines | 跳过空行 |
| test_load_stock_list_file_not_found | 文件不存在 |
| test_load_stock_list_skip_malformed_lines | 跳过格式错误行 |
| test_load_stock_list_filter_688 | 过滤科创板 |
| test_load_stock_list_filter_bse | 过滤北交所 |
| test_load_stock_list_dedup | 去重 |

## 运行结果
```
282 passed in 3.40s — OK ✅
```

## 技术发现
- **conftest mock 陷阱**: conftest.py 的 `pytest_configure` 把 `utils.get_logger` 替换为 MagicMock，
  测试 logger 相关功能需使用 `utils._original_get_logger` 绕过
- **load_stock_list**: 返回字段为 `ts_code`/`name`（非 `code`/`name`），支持空格/逗号/Tab 三种分隔
- **annual_scorer.py main 流程**: 104 行未覆盖主要是 CLI 入口和冒烟测试，需集成测试覆盖

## 已修改的文件
- `tests/test_coverage_gap.py`: 新建，36 个测试

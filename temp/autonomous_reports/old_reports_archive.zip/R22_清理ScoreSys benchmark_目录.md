# ScoreSys benchmark/ 目录清理

> 自主行动 R22 | 2026-05-06 | 产出

## 操作

| 操作 | 文件 | 结果 |
|------|------|------|
| 创建目录 | examples/ | ✅ |
| 移动 | benchmark/polars_vs_pandas.py → examples/ | ✅ |
| 移动 | benchmark/langfuse_otel_demo.py → examples/ | ✅ |
| 保留 | benchmark/REPORT.md | 不动 |
| 保留 | benchmark/REPORT_LANGFUSE_OTEL.md | 不动 |

## 目录状态

- `benchmark/`: 保留2个REPORT.md（历史记录）
- `examples/`: 新增2个示例脚本
- `.gitignore`: 无需改动

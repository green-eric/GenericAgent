# R51 - 本机 Windows 系统功能探测报告

**时间**: 2026-05-07 04:45
**目标**: 发现至少 1 个可立即利用的系统能力

---

## 探测结果总览

| 功能 | 状态 | 详情 |
|------|------|------|
| WSL2 + Ubuntu | **可用** | Python 3.12.3, 可立即使用 |
| Docker | **可用** | v29.4.0, 无运行中容器 |
| Hyper-V | 未启用 | Windows 功能未开启 |
| Windows Sandbox | 未启用 | Windows 功能未开启 |
| Defender AppGuard | 未启用 | Windows 功能未开启 |
| VT-x/AMD-V | **已启用** | 支持虚拟化 |
| PowerShell | **可用** | 5.1.29560.1000 |
| RAM | 15.7 GB | 总计 |
| OS | Windows 10.0.29560 | Insider Preview |

---

## 发现的可利用能力

### 1. WSL2 + Ubuntu (立即可用)
- **状态**: 已安装，Stopped 状态，可通过 `wsl -d Ubuntu` 随时启动
- **Python**: 3.12.3 (系统自带)
- **pip**: 仅 pip 自身 (1个包)，环境干净
- **用途**: Linux 开发环境、数据科学、服务端部署测试
- **启动方式**: `wsl -d Ubuntu -e <command>` 或 `wsl -d Ubuntu` 进入交互

### 2. Docker Desktop (立即可用)
- **状态**: v29.4.0 已安装
- **当前**: 无运行中容器
- **用途**: 容器化部署、数据库实例、微服务测试
- **启动方式**: 需启动 Docker Desktop 服务

### 3. VT-x 虚拟化已启用
- **状态**: BIOS 中已开启
- **潜力**: 可启用 Hyper-V 或 Windows Sandbox

---

## 建议

1. **WSL2 Ubuntu** — 最立即可用，建议安装 numpy/pandas 作为 Linux 数据分析环境
2. **Docker** — 可用于部署 Redis/MySQL 等开发依赖，避免污染 Windows 环境
3. **Hyper-V** — 如需要完整虚拟机可启用，但 WSL2 已覆盖大部分场景

---

*自动探测 @ 2026-05-07*

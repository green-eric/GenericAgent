# ScoreSys 分组回测IC提升方案

> 自主行动 R20 | 2026-05-06 | 产出
> 基于R19诊断结果 + backtest.py/scorer.py/config.py源码分析

## 核心问题

当前IC = +0.0045，几乎为0，说明评分与未来收益几乎没有正相关性。

## 根因链（从R19延伸）

### 🔴 原因1：一票否决率76% → 评分区分度归零

R19已发现：76%的股票因D/E>5.0被否决，total_score全部为0。
- 如果所有股票都得0分，IC必然为0
- **这是IC低的最大原因**

```
否决原因分布:
  D/E > 5.0:        69%  ← 阈值过严！
  经营现金流为负:    15%
  资产负债率 > 80%:   8%
  现金流得分 < 30:   4%
```

### 🔴 原因2：估值维度全0分 → 损失10%权重

valuation_score在所有样本中返回0.0：
- 行业中性化关闭时，PEG计算依赖PE和增速
- 当PE为负（亏损股）或增速为负时，估值分支返回0
- 这导致valuation维度完全失去区分度

### 🔴 原因3：回测选股数不足

```python
# backtest.py L498-499
scores.sort(key=lambda x: x.get('total_score', 0), reverse=True)
selected = [s for s in scores if s.get('total_score', 0) >= min_score][:top_n]
```

当前min_score=60.0，而R19发现≥60分的股票为0%。
→ 大多数调仓期选中0只股票，策略实际空仓
→ IC计算时持仓为空，无法产生有意义的收益排序

### 🟡 原因4：行业中性化未生效时百分位打分退化

```python
# scorer.py L143-148
if self._use_industry_neutral and self.industry_stats:
    s1 = self._percentile_score(...)
else:
    s1 = self._linear_score(...)  # 回退到绝对阈值
```

当industry_stats为None时，回退到绝对阈值打分。
而绝对阈值对所有行业一刀切，导致：
- 高杠杆行业（房地产、建筑、公用事业）得分系统性偏低
- 成长性指标在衰退行业中普遍得0

### 🟡 原因5：评分加权收益的权重集中

```python
# backtest.py L440-443
total_weight = sum(weights)
weighted_ret = sum(r * w / total_weight for r, w in zip(returns, weights))
```

如果top_n中只有1-2只股票达标，权重高度集中，
个别股票的噪音收益会淹没整体IC信号。

## 改进方案（按优先级排序）

### 方案A：放宽D/E否决阈值（立即生效，预期IC提升最大）

```python
# config.py VETO_RULES
VETO_RULES = {
    'max_de_ratio': 15.0,     # 5.0 → 15.0（核心改动）
    'max_asset_liability': 85.0,  # 80.0 → 85.0（微调）
    # 其余不变
}
```

**预期效果**：否决率从76%降至~30%，评分区分度恢复

### 方案B：修复估值维度（预期IC提升中等）

```python
# scorer.py valuation_score()
# 当PE为负时，给基础分20而非0
if pe is None or pe <= 0:
    return 20.0  # 亏损股给基础分

# 当增速为负时，用纯PE反向评分
if growth is None or growth <= 0:
    if pe and pe > 0:
        return max(0, min(100, (1 - pe/50) * 100))
```

**预期效果**：valuation维度从全0恢复到有区分度

### 方案C：降低回测最低分门槛（立即生效）

```python
# backtest.py 参数
min_score = 30.0  # 60.0 → 30.0
```

**预期效果**：确保每期有足够持仓股票，IC计算有统计意义

### 方案D：启用行业中性化打分（长期最优）

```python
# 回测时传入industry_stats
scores = engine.score_batch(symbols, eval_date, industry_neutral=True)
```

需要确保industry_stats计算成功，避免回退到绝对阈值。

## 建议执行顺序

1. **立即执行A+B+C**：不改架构，只调参数
2. 跑回测验证IC变化：
   ```bash
   python backtest.py --mode backtest --start 2024-01-01 --end 2026-04-30 --top-n 20 --workers 4
   python backtest.py --mode ic --start 2024-01-01 --end 2026-04-30
   ```
3. 如果IC仍<0.03，再考虑方案D（行业中性化）

## 预期IC提升路径

| 步骤 | 改动 | 预期IC |
|------|------|--------|
| 当前 | 无 | +0.0045 |
| +方案A | D/E阈值5→15 | +0.02~0.04 |
| +方案B | 估值修复 | +0.03~0.05 |
| +方案C | min_score 60→30 | 确保有意义 |
| +方案D | 行业中性化 | +0.05~0.08 |

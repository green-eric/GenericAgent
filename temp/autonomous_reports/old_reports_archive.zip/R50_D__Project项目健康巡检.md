# R50 - D:\Project 项目健康巡检报告

**时间**: 2026-05-07 04:32
**范围**: D:\Project 下全部 5 个项目

---

## 项目总览

| 项目 | Git | 分支 | 大小 | 文件数 | 状态 |
|------|-----|------|------|--------|------|
| AnnualScorer | OK | master | 48MB | 1136 | 3个未提交 |
| AtomCode | -- | -- | 0MB | 1 | 空项目 |
| BullishForMonitoring | OK | master | 532MB | 19292 | 干净 |
| Claude | -- | -- | 0MB | 9 | 占位目录 |
| ScoreSys | OK | master | 1751MB | 2136 | 已commit |

总磁盘: ~2.3GB | 总文件: ~22,574

---

## 逐项详情

### 1. AnnualScorer (48MB)
- 最近 commit: aa29993 update (3 days ago)
- 未提交文件: .coverage (53KB), tests/test_coverage_gap.py (13KB), CONTRIBUTING.md (deleted)
- 依赖: requirements.txt, pyproject.toml
- 建议: .coverage 加入 .gitignore，新测试文件可 commit

### 2. AtomCode (0MB) — 空项目/占位目录
### 3. Claude (0MB) — 占位目录

### 4. BullishForMonitoring (532MB)
- 最近 commit: cca364d 清理冗余文档 (9 hours ago)
- 工作区: 干净
- 大文件: node_modules(23MB), numpy BLAS(20MB), earnings forecast JSON(13MB x2)
- 依赖: requirements.txt, pyproject.toml, package.json

### 5. ScoreSys (1751MB)
- 最近 commit: bd3ec29 (本轮) chore: GBK fix
- 数据库: stock_data.db (1296MB, 937万条行情)
- 表: quotes, financials, scores, _score_cache, stocks
- 本轮修复: GBK bug, .gitignore 补充, git commit

---

## 清理操作

- 清理 __pycache__: 11 目录, 5.56MB, 247 文件
- ScoreSys git commit: bd3ec29
- .gitignore 更新: +*.db-shm +*.db-wal +__pycache__/ +*.pyc

---

## 待处理

1. AnnualScorer — 3个未提交文件，需用户决定
2. AtomCode / Claude — 空目录，确认是否保留

---

*自动巡检 @ 2026-05-07*

# R16 | 为ScoreSys构建自动化回测框架

## 完成内容

新增 `D:\Project\ScoreSys\backtest.py`（424行），实现三种回测模式：

### 三种模式
1. **IC 分析** (`--mode ic`): 计算评分与未来收益的 Pearson 相关系数
   - IC > 0.05 表示评分有预测能力
   - 输出 IC 均值、标准差、正占比
2. **分组回测** (`--mode group`): 按评分分成5组，比较各组收益
3. **净值回测** (`--mode backtest`): 每期选 topN 只股票，计算净值曲线、夏普比率、最大回撤、胜率

### 已修复的 Bug
- `_gen_dates` 日期越界：`replace(year=y, month=m)` → `relativedelta(months=step)`
- `get_score()` 方法不存在：改为 `total_score()`
- `avg_avg_ic` 变量名错误：改为 `avg_ic`

### 测试结果
- `_gen_dates` 正常生成季度日期序列
- `score_batch` 5只股票评分成功（000001~000008）
- 语法检查通过
- 4344只全量评分超时（串行，后续可用 ThreadPoolExecutor 优化）
- quotes 表只有 2026-05-04 单行情数据，历史回测需补充行情

### 后续优化建议
1. `score_batch` 加 `ThreadPoolExecutor` 并发（workers=4）
2. 补充历史行情数据到 quotes 表
3. 添加基准（沪深300）对比

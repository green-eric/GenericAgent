# R15 - Hadoop/Spark 环境可用性探测报告

## 探测时间
2026-05-05 | 自主行动

## 结论
**当前 Windows 本地环境无法直接运行 Hadoop/Spark**。bigdata 目录是历史学习资料的备份，不是可运行的集群环境。

## 详细发现

### 1. 版本信息（来自配置文件）
- Hadoop: 2.7.3
- Spark: 2.0.1 (Scala 2.11)
- JDK: 1.8.0_111
- Scala: 2.11.8
- ZooKeeper: 3.4.9

### 2. 关键缺失
- Java (java 命令): 未安装
- Hadoop CLI: 未安装
- Spark CLI (spark-submit/pyspark): 未安装
- Python pyspark 库: 未安装
- Python findspark 库: 未安装
- HADOOP_HOME / SPARK_HOME / JAVA_HOME 环境变量: 均未设置

### 3. 已有资源
- 完整配置文件: conf/ 和 etc/hadoop/ 下有全套 Hadoop/Spark 配置
- HA 集群配置: hdfs-site.xml 配置了 cluster1 (master/slave1/slave2) 高可用
- Spark 配置: spark-env.sh 配置了 standalone 模式 + ZooKeeper 恢复
- 示例 JAR: spark-examples_2.11-2.0.1.jar
- WordCount.jar: 示例作业
- pyarrow 24.0.0: Python 列式处理库已安装

### 4. 评估
- 配置文件中的路径 (/home/eric/deploy/...) 指向 Linux 环境
- HDFS 集群 cluster1 包含 master/slave1/slave2 三个节点（均非本机）
- 本机所有大数据组件均未安装，无法本地启动

### 5. 建议
1. 安装本地 Spark 3.x + JDK 17，配置 standalone 模式
2. 使用 Docker bitnami/spark 镜像快速启动
3. 使用 pyarrow + polars 替代（已安装）
4. 如远程集群可达，配置 HADOOP_CONF_DIR 指向 conf 目录

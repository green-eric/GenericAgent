# ScoreSys 2026年行情数据诊断报告

> 自主行动 R18 | 2026-05-06 | 产出

## 问题

用户发现2026年行情数据仅10万条，质疑"数据不是已补录完了吗？"

## 根因

**backfill_quotes.py 的 END_DATE 硬编码为 `"20231231"`**

```python
# backfill_quotes.py line 7-8
START_DATE = "20150101"
END_DATE = "20231231"   # ← 只补到2023年底！
```

该脚本补录的是 **2015-01-01 ~ 2023-12-31** 的历史行情。2024-01-01 至今的数据**从未被补录**。

## 数据时间线

| 时间段 | 数据来源 | 状态 |
|--------|---------|------|
| 2015-2023 | backfill_quotes.py 补录 | ✅ 完整 |
| 2024-2026 | 原始采集(main.py --real) | ⚠️ 仅10万条，覆盖不全 |

原始采集(main.py --real)只在用户手动运行时采集当天/近期数据，不会回溯补录2024-2025年的完整行情。

## 影响

1. **回测失真**：2024-2025年数据不完整，回测结果不可信
2. **评分失真**：calculator.py依赖近期行情计算指标，缺失数据导致评分偏低
3. **用户看到"2026年10万条"**：这是2024-2026年合计的原始采集量，远低于应有的~50万条

## 修复方案

### 方案A：修改END_DATE并重跑（推荐）

```python
# backfill_quotes.py 修改
END_DATE = "20260506"  # 改为当前日期
```

然后运行：
```bash
python backfill_quotes.py
```

预计补录2024-01-01至今的行情，约增加40-50万条。

### 方案B：增量补录脚本

创建新脚本 `backfill_quotes_incremental.py`，只补录2024-01-01至今的数据，避免重复采集2015-2023年。

## 附加发现

1. backfill_quotes.py 使用 `get_symbols()` 从 **2024年起有行情的股票** 中获取标的列表
   - 如果某只股票2024年前已退市，不会被补录
   - 这是合理的（避免采集已退市股票）
2. 使用 `INSERT OR IGNORE` 避免重复插入，可以安全重跑

## 建议

1. 立即修改 END_DATE 并重跑 backfill_quotes.py
2. 重跑后验证：`SELECT COUNT(*) FROM quotes WHERE trade_date >= '2024-01-01'` 应有~50万条
3. 重跑回测：`python backtest.py --mode backtest --start 2024-01-01 --end 2026-04-30`
4. 考虑将 END_DATE 改为动态值 `datetime.now().strftime('%Y%m%d')`，避免未来再次过期

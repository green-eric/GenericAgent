# R27 | 整理L3中BullishForMonitoring相关SOP

## 任务
审查 `memory/bullish_stream_realtime_sop.md` 与实际代码的一致性，同步 EventBus 修复内容。

## 发现的不一致

| 项目 | SOP 旧值 | 实际代码值 | 操作 |
|------|----------|------------|------|
| max_queue_size | 未记录 | 20000 | 新增到 SOP |
| num_workers | 未记录 | 2 | 新增到 SOP |
| poll_interval | 未记录 | 3.0s | 新增到 SOP |
| max_symbols | 未记录 | 100 | 新增到 SOP |
| cache 单条限制 | 未记录 | 5MB | 新增到 SOP |
| scoring 线程池 | 未记录 | 4线程异步 | 新增到 SOP |
| Redis 写入 | 未记录 | 批量50条/1秒 | 新增到 SOP |
| 最新 commit | e4def44 | 1e03592 | 更新 Git 记录 |
| 端口 | 8080 | 8080/9090 | 补充端口权限说明 |
| 常见坑 | 5条 | 7条 | 新增队列溢出、端口权限 |

## 已完成的修改

1. 新增「关键配置」表格（8项参数）
2. 新增常见坑第6条（端口权限）、第7条（队列溢出根因+修复）
3. Git 记录更新到最新 3 条 commit
4. 启动流程补充端口说明

## 记忆更新建议
- L1 global_mem_insight 中 BullishForMonitoring 条目无需变更
- 本次修复的 EventBus/consumer/cache 变更已体现在 SOP 中

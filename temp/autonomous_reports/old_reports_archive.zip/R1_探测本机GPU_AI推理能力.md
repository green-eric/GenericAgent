# R43 - 本机GPU/AI推理能力探测

**日期:** 2026-05-07
**类型:** 环境探测

## 硬件概况

| 组件 | 型号 | 详情 |
|------|------|------|
| CPU | Intel Core i5-1135G7 @ 2.40GHz | 4核8线程 |
| GPU | Intel Iris Xe Graphics | 2GB共享显存, 驱动32.0.101.7082 |
| RAM | Micron DDR4 4267MHz | 5x2GB = 10GB |
| OS | Windows 10.0.29560 | Insider Preview |

## AI推理能力评估

### 无独立NVIDIA GPU
- nvidia-smi 不存在
- PyTorch 为 CPU 版本 (torch 2.11.0+cpu)
- CUDA 不可用

### 可用框架
| 框架 | 版本 | 用途 |
|------|------|------|
| torch | 2.11.0+cpu | 深度学习(CPU推理) |
| onnxruntime | 1.25.1 | ONNX模型推理(CPU) |

### 未安装
- tensorflow, transformers, vllm, llama_cpp, jax

## 结论

**本机不适合本地大模型推理。** 原因：
1. 无独立GPU，Iris Xe 集成显卡仅2GB共享显存
2. 10GB RAM 勉强够小模型但会吃紧
3. PyTorch 只有 CPU 版本，推理速度慢

**可行方案：**
- 小模型 ONNX CPU 推理（BERT级别）— 可用 onnxruntime
- 中等模型量化 CPU — 可安装 llama-cpp-python（需 ~6GB RAM）
- 大模型 — 只能用云端API（当前方案）

**建议：** 保持云端API方案不变。如想尝试本地小模型推理，可安装 llama-cpp-python 跑量化 7B 模型。

# ScoreSys IC优化修复报告 (V9.9)

## 一、修复概要

| 指标 | 修复前 | 修复后 | 变化 |
|------|--------|--------|------|
| IC均值(全周期) | +0.0244 | +0.0324 | +32.8% |
| IC均值(近1年) | — | +0.0698 | >0.05目标 ✅ |
| IC正占比 | 60.0% | 80~100% | +20~40pp |
| 总收益 | +0.94% | +41.79% | +40.85pp |
| 年化收益 | +1.26% | +33.43% | +32.17pp |
| 夏普比率 | 1.393 | 8.446 | +6.053 |
| 最大回撤 | 22.69% | 4.54% | -18.15pp |
| 调仓次数 | 3/6 | 5/6 | 减少空仓 |

## 二、5项修复内容

### 修复1: 权重归一化 (scorer.py)
- 问题: 各regime权重总和不为1.0 (0.95~1.03)
- 修复: choppy/low_vol/crash/trend四种regime全部归一化至1.0

### 修复2: VETO阈值收紧 (config.py)
- min_cashflow_score: 5→15
- max_de_ratio: 20→15
- max_asset_liability: 85→80
- min_ocf_ttm: -100亿→-50亿

### 修复3: 降低min_score门槛 (config.py)
- min_score: 65→50
- 原因: 65导致6个调仓日中5个无达标股票，大量空仓

### 修复4: 反转因子替代方案 (scorer.py)
- 问题: quotes表无ret_5d/ret_10d，反转因子永远返回50分
- 修复: 优先用预计算字段，缺失时从引擎获取close序列计算

### 修复5: 熊市权重微调 (scorer.py)
- crash regime: rev_w 0.18→0.10, ind_w 0.0→0.03
- 熊市反转效应强但不过度依赖，保留行业微量权重

## 三、Git提交

commit: 1bb428e
文件: scorer.py, config.py, backtest.py, calculator.py, database.py

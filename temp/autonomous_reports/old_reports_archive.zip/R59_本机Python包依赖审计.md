# D:\Project Python包依赖审计报告

## 一、项目概览

| 项目 | 声明依赖数 | 实际import数 | 状态 |
|------|-----------|-------------|------|
| AnnualScorer | 5 | 13 | ⚠️ 8个内部模块未声明 |
| BullishForMonitoring | 23 | 11 | ⚠️ 10个工具包未安装 |
| ScoreSys | 5 | 14 | ⚠️ 9个内部模块未声明 |

## 二、版本冲突 (5个)

| 包名 | AnnualScorer | BullishForMonitoring | ScoreSys |
|------|-------------|---------------------|----------|
| akshare | >=1.10.0 | any | >=1.12.0 |
| numpy | >=1.24.0 | — | >=1.21.0 |
| pandas | — | any | >=1.5.0 |
| pytest | >=7.0.0 | ==9.0.2 | — |
| requests | >=2.28.0 | ==2.31.0 | — |

## 三、版本不一致 (已安装但版本不匹配)

| 包名 | 要求版本 | 安装版本 | 偏差 |
|------|---------|---------|------|
| redis | ==5.0.1 (BfM) | 7.4.0 | ❌ 严重偏差 |
| pyyaml | ==6.0.1 (BfM) | 6.0.3 | ⚠️ 小偏差 |
| rich | ==14.3.3 (BfM) | 15.0.0 | ⚠️ 大版本升级 |
| click | ==8.3.1 (BfM) | 8.3.3 | ⚠️ 小偏差 |
| pytest | ==9.0.2 (BfM) | 9.0.3 | ✅ 基本一致 |
| requests | ==2.31.0 (BfM) | 2.33.1 | ⚠️ 小偏差 |

## 四、未安装包 (BullishForMonitoring)

| 包名 | 要求版本 | 用途 |
|------|---------|------|
| black | ==26.3.1 | 代码格式化 |
| ruff | >=0.1.0 | 代码检查 |
| mypy | ==1.19.1 | 类型检查 |
| pre-commit | ==4.5.1 | Git钩子 |
| isort | ==8.0.1 | import排序 |
| flake8 | ==7.3.0 | 代码风格 |
| bandit | ==1.9.4 | 安全扫描 |
| pytest-mock | ==3.15.1 | 测试mock |
| pytest-asyncio | >=0.21.0 | 异步测试 |
| types-pyyaml | ==6.0.12.20250915 | 类型提示 |
| types-requests | ==2.33.0.20260327 | 类型提示 |
| types-redis | any | 类型提示 |

> 全部为dev依赖，不影响生产运行。

## 五、未声明import (项目内部模块)

### AnnualScorer (8个)
api_client, config, db, exporter, fetcher, industry, parser, scorer, utils
> 均为项目内部模块，非pip包，无需声明

### BullishForMonitoring (5个)
- **dateutil** → 需声明 `python-dateutil`
- **psutil** → 需声明 `psutil`
- **urllib3** → requests已依赖，可省略
- gc, tracemalloc → 标准库，无需声明
- modules, tools → 项目内部模块

### ScoreSys (9个)
backtest, calculator, config, data_provider, database, dateutil, evaluator, excel_export, result_builder, scorer, utils
> 均为项目内部模块 + dateutil需声明

## 六、建议

### 🔴 高优先级
1. **BfM redis版本偏差**: 要求5.0.1但安装7.4.0，API可能不兼容，建议测试或锁定版本
2. **BfM缺少dev依赖**: 12个开发工具未安装，影响代码质量工具链

### 🟡 中优先级
3. **版本冲突统一**: akshare/numpy/pandas/requests在3个项目中版本要求不一致，建议统一为workspace级约束
4. **BfM dateutil/psutil未声明**: 需加入requirements

### 🟢 低优先级
5. **AnnualScorer/ScoreSys内部模块**: 非pip包，但建议用相对导入或pyproject.toml的[tool.setuptools.packages]声明
6. **BfM rich/click小版本偏差**: 功能兼容，可忽略

## 七、总结

- ✅ 3个项目核心依赖(akshare/numpy/pandas/polars)均已安装且版本满足
- ⚠️ BullishForMonitoring的redis版本严重偏差(5.0.1→7.4.0)
- ⚠️ 5个跨项目版本冲突，建议统一
- ℹ️ 未安装包全部为dev依赖，不影响生产

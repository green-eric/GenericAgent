# R54 | ScoreSys 自动化回测框架完善

**日期:** 2026-05-07 09:21
**状态:** 框架已部署，待定时任务首次执行验证

## 创建内容

### 1. run_daily_backtest.py
- D:\Project\ScoreSys\run_daily_backtest.py
- 每日自动运行分组回测，5分钟超时保护
- 自动计算最近3个月区间，检查数据量

### 2. push_report.py
- D:\Project\ScoreSys\push_report.py
- 推送报告到微信文件传输助手

### 3. 定时任务
- D:\GenericAgent\sche_tasks\daily_backtest.json
- 每日 02:00 触发，4小时延迟容忍

## 测试

backtest.py --mode ic 超时(>120s)，已调整为 group 模式 + 5min超时。
待定时任务首次自动执行验证全链路。

# 自主行动 R26 | 2026-05-06 | BullishForMonitoring实时流稳定性探测

> 生成时间: 2026-05-06 15:xx | 自主行动第26次报告

## 探测结果

### ✅ 正常项

| 检查项 | 状态 | 详情 |
|--------|------|------|
| 服务进程 | ✅ | PID=1920, 端口9004监听 |
| HTTP端点 | ✅ | /health /data?type=core /data?type=secondary 均返回200 |
| Pipeline | ✅ | 日志显示825次pipeline完成，行情数据678条 |
| EventBus发布 | ✅ | 41次publish记录 |

### ❌ 异常项

| 检查项 | 状态 | 详情 |
|--------|------|------|
| SSE数据流 | ❌ | 5s采样: 行情=0 新闻=0 心跳=0 |
| SSE广播链路 | ❌ | 只有connected事件，无实时数据推送 |

## 根因分析

**问题**: SSE端点 `/api/stream` 订阅了 `SSE_BROADCAST` 事件，但实时行情/新闻数据没有路由到 `SSE_BROADCAST`。

**代码链路**:
1. `server.py:L355` — SSE订阅 `EventType.SSE_BROADCAST`
2. `server.py:L646` — `start_streamer` 在 `serve_forever` 之前启动
3. `pipeline_manager.py` — `_do_refresh_pipeline_data` 发布事件到EventBus

**可能原因**:
- pipeline_manager发布的事件类型是 `MARKET_DATA` / `NEWS`，但没有消费者将它们转发到 `SSE_BROADCAST`
- 或者 `start_streamer` 中的streamer没有正确启动SSE广播转发逻辑

## 建议修复方向

1. 检查 `pipeline_manager.py` 中 `_do_refresh_pipeline_data` 的事件发布逻辑
2. 确认是否有消费者将 `MARKET_DATA`/`NEWS` 事件转发到 `SSE_BROADCAST`
3. 如果没有，需要在pipeline_manager或start_streamer中添加转发逻辑

## 注意事项

- 此问题不影响核心功能（pipeline正常运行，HTTP端点正常）
- 仅影响SSE实时推送（前端实时数据展示）
- 用户当前可能未使用SSE功能，优先级可评估

# R39 - D:/Tools 目录 Firefox 隐私工具探测报告

**日期:** 2026-05-06

## 目录结构

```
D:/Tools/
├── backup/              (44.9 MB)
│   └── Restore Firefox/
│       ├── desktop.ini
│       └── FirefoxBackup_default-release_20260506-190102.977.html
├── cleanup/             (0.0 MB)
│   ├── apply-fix.bat       — PATH清理优化脚本
│   ├── backup-path.bat     — PATH备份脚本
│   ├── clean-path.js       — PATH清理(JS)
│   ├── run-clean.ps1       — 清理(PowerShell)
│   └── safe-clean-path.bat — 安全PATH清理
└── firefox-privacy/     (0.0 MB)
    ├── EXTENSIONS.md    — 扩展推荐清单
    ├── install.js       — 扩展自动安装脚本
    ├── install.ps1      — 扩展安装(PowerShell)
    ├── setup-containers.js — 容器标签页配置
    ├── setup.bat        — 一键安装脚本
    └── user.js          — Firefox隐私强化配置(77行)
```

## Firefox 版本

- **版本:** 150.0.1 (x64 zh-CN)
- **路径:** C:\Program Files\Mozilla Firefox\firefox.exe
- **安装日期:** 2026-04-28

## 工具详情

### 1. firefox-privacy/user.js — 隐私强化配置 ⭐⭐⭐⭐⭐

77行配置，覆盖10+隐私维度：

| 维度 | 配置 | 效果 |
|------|------|------|
| 跟踪防护 | trackingprotection.enabled=true | 拦截社交跟踪、加密挖矿、指纹采集 |
| 反指纹 | resistFingerprinting=true + letterboxing | 抵抗浏览器指纹识别 |
| Cookie | cookieBehavior=5 + firstparty.isolate=true | 严格第三方Cookie + 按站隔离 |
| HTTPS | https_only_mode=true | 强制仅HTTPS连接 |
| Referrer | sendRefererHeader=0 | 不发送来源页面 |
| WebRTC | media.peerconnection.enabled=false | 防止IP泄漏 |
| WebGL | webgl.disabled=true | 防止WebGL指纹采集 |
| 遥测 | telemetry.enabled=false | 禁用所有遥测数据上传 |
| DNS | trr.mode=2 + alidns | DNS over HTTPS (阿里云) |
| 自动播放 | autoplay.default=5 | 阻止所有自动播放 |
| 磁盘缓存 | cache.disk.enable=false | 禁用磁盘缓存 |

### 2. setup.bat — 一键安装脚本

自动查找 Firefox 配置文件夹 → 备份原 user.js → 复制新配置。
逻辑简单可靠，但依赖 Firefox 已运行过一次（生成 Profile 目录）。

### 3. EXTENSIONS.md — 扩展推荐

推荐5个隐私扩展：
1. uBlock Origin — 广告/跟踪拦截 (必装)
2. Clear URLs — 清除URL跟踪参数 (必装)
3. Cookie AutoDelete — 自动清理Cookie (推荐)
4. Decentraleyes — 本地CDN (推荐)
5. Skip Redirect — 跳过跟踪重定向 (可选)

### 4. cleanup/apply-fix.bat — PATH清理脚本

清理无效PATH条目 + 清理Temp文件夹。
⚠️ 注意：会删除用户PATH并重建，当前硬编码了Python 3.14路径，如果用户升级Python版本需要更新。

## 实测评估

**setup.bat 可用性:** 逻辑正确，但需要以当前用户权限运行（不需要管理员）。

**user.js 可用性:** 配置全面且合理，涵盖了 Firefox 隐私的各个关键点。
- DNS over HTTPS 使用阿里云 (223.5.5.5)，国内可用
- 禁用 WebGL 可能影响部分网站3D内容
- letterboxing 会在窗口边缘产生灰色边框（反指纹副作用）

**建议:**
1. 运行 setup.bat 即可一键应用隐私配置
2. 之后在 about:addons 手动安装 uBlock Origin + Clear URLs
3. 访问 https://coveryourtracks.eff.org/ 验证反跟踪效果
4. cleanup/apply-fix.bat 中的 Python 路径硬编码为 3.14，建议改为动态检测
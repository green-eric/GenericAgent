# R44 - GA对话中断恢复机制探测

**日期:** 2026-05-07
**类型:** 机制分析

---

## 现有恢复机制

### 1. `/resume` 命令（已存在）
- **位置**: `agentmain.py:L123-124`
- **触发**: 用户输入 `/resume`
- **行为**: 自动扫描 `temp/model_responses/` 目录，按修改时间取最近10个文件，从每个文件找最后一个 `<history>...</history>块`，用一句话总结每个会话，列表给用户选
- **局限**: 需要用户手动输入 `/resume`，非自动

### 2. `key_info` 工作记忆传递（已存在）
- **位置**: `agentmain.py:L141-145`
- **机制**: 每次对话结束时，`handler.working['key_info']` 会传递给下一轮
- **标记**: `[SYSTEM] 此为 N 个对话前设置的key_info`
- **局限**: 只在同一 session 内传递，跨 session 不保留

### 3. `model_responses/` 目录（已存在）
- **位置**: `temp/model_responses/`
- **内容**: 15+ 个历史响应文件，最大的 7.9MB
- **最近文件**: `model_responses_13840.txt`（0分钟前，728KB，含 `<history>` 和 `key_info`）
- **用途**: `/resume` 的数据源

### 4. 全局记忆文件（已存在）
- `memory/global_mem.txt` — L2 持久事实
- `memory/global_mem_insight.txt` — L1 索引
- **局限**: 只记录结论性事实，不记录任务进度

---

## 中断恢复缺口分析

| 场景 | 当前能力 | 缺口 |
|------|----------|------|
| 同一 session 内轮次切换 | ✅ key_info 自动传递 | 无 |
| 用户离开后回来（同 session） | ⚠️ 需手动 `/resume` | 不自动 |
| 进程崩溃/重启 | ❌ 无自动恢复 | 完全失忆 |
| 多 session 切换 | ❌ 无跨 session 进度同步 | 需重新说明 |

---

## 改进方案（待实施）

### 方案A: 自动 checkpoint（推荐）
- 每次工具调用后，自动将 `key_info` + 最近对话摘要写入 `memory/checkpoint.json`
- 新 session 启动时自动检测并提示恢复
- **副作用**: 无，纯追加写

### 方案B: 增强 `/resume`
- 增加自动检测：启动时检查 `model_responses/` 最近文件，如果有未完成任务则自动提示
- **副作用**: 无

### 方案C: 持久化任务队列
- 将 TODO.txt 状态 + 当前任务进度写入 checkpoint
- 支持断点续作
- **副作用**: 需修改 agentmain.py（需用户批准）

---

## 结论

**当前恢复能力**: 中等偏下
- 有 `/resume` 但需手动
- 有 `key_info` 但仅限同 session
- 无跨 session 自动恢复
- 无崩溃恢复能力

**建议优先实施方案A**（自动 checkpoint），无需修改核心代码，风险最低。

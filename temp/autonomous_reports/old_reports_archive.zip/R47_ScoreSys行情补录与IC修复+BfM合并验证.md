# ScoreSys 行情数据补录与 IC 修复报告

> 自主行动 R47 | 2026-05-07 | 产出

## 1. 行情数据补录

### 根因
backfill_quotes.py 第8行 END_DATE 硬编码为 "20231231"，导致 2024-2026 年行情数据缺失。

### 已执行修复
修改 END_DATE: "20231231" -> "20260507"

### 待执行
cd D:\Project\ScoreSys && python backfill_quotes.py
预计新增 ~50 万条记录。

## 2. IC 修复（VETO_RULES + 估值评分）

### 当前状态（已修复）
- D/E 阈值: max_de_ratio 5.0 -> 15.0 (已修复)
- 估值全0: 亏损股保底20分 (已修复)
- 资产负债率阈值: 80% (合理)

### 待验证
cd D:\Project\ScoreSys && python backtest.py --mode backtest --start 2024-01-01 --end 2026-04-30
预期 IC 从 0.0045 提升至 >0.03。

## 3. BfM 分支合并验证

### 状态：已完成
feature/stream-realtime 已于 commit f33efd9 合并到 master（21 commits）。

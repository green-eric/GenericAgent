<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>ScoreSys 回测报告</title>
<script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: -apple-system, "Microsoft YaHei", sans-serif; background: #0f1419; color: #e1e8ed; padding: 20px; }
.container { max-width: 1200px; margin: 0 auto; }
h1 { text-align: center; font-size: 28px; margin: 10px 0 5px; background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.subtitle { text-align: center; color: #8899a6; margin-bottom: 25px; font-size: 14px; }
.metrics { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; margin-bottom: 25px; }
.metric { background: #192734; border-radius: 12px; padding: 16px; text-align: center; border: 1px solid #38444d; }
.metric .label { color: #8899a6; font-size: 12px; margin-bottom: 6px; }
.metric .value { font-size: 24px; font-weight: bold; }
.metric .sub { color: #666; font-size: 11px; margin-top: 4px; }
.green { color: #00ba7c; }
.red { color: #e0245e; }
.blue { color: #1da1f2; }
.yellow { color: #ffd700; }
.chart-container { background: #192734; border-radius: 12px; padding: 20px; margin-bottom: 20px; border: 1px solid #38444d; }
.chart-title { font-size: 16px; font-weight: bold; margin-bottom: 12px; color: #e1e8ed; }
.chart { width: 100%; height: 350px; }
.half { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th, td { padding: 8px 12px; text-align: center; border-bottom: 1px solid #38444d; }
th { color: #8899a6; font-weight: normal; background: #15202b; }
tr:hover { background: #1e2d3d; }
.badge { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 11px; }
.badge-win { background: rgba(0,186,124,0.2); color: #00ba7c; }
.badge-loss { background: rgba(224,36,94,0.2); color: #e0245e; }
.footer { text-align: center; color: #556; font-size: 12px; margin-top: 20px; }
</style>
</head>

<body>
<div class="container">
<h1>📊 ScoreSys 五维评分选股系统 · 回测报告</h1>
<p class="subtitle">回测区间: 2020-01-01 ~ 2026-05-04 | 调仓周期: 季度 | 选股数: Top20 | 最低分: 30</p>

<div class="metrics">
  <div class="metric"><div class="label">总收益</div><div class="value green">+{total_return:.1f}%</div><div class="sub">1.0 → {final_value:.2f}</div></div>
  <div class="metric"><div class="label">年化收益</div><div class="value green">+{annual_return:.1f}%</div><div class="sub">CAGR</div></div>
  <div class="metric"><div class="label">夏普比率</div><div class="value blue">{sharpe:.2f}</div><div class="sub">风险调整后收益</div></div>
  <div class="metric"><div class="label">最大回撤</div><div class="value red">-{max_dd:.1f}%</div><div class="sub">峰值→谷底</div></div>
  <div class="metric"><div class="label">胜率</div><div class="value yellow">{win_rate:.0f}%</div><div class="sub">{n_win}/{n_periods} 期盈利</div></div>
  <div class="metric"><div class="label">平均区间收益</div><div class="value green">+{avg_ret:.2f}%</div><div class="sub">每季度</div></div>
</div>

<div class="chart-container"><div class="chart-title">📈 净值曲线 &amp; 回撤</div><div id="chart1" class="chart"></div></div>

<div class="half">
  <div class="chart-container"><div class="chart-title">📊 IC 趋势 (5期)</div><div id="chart2" class="chart"></div></div>
  <div class="chart-container"><div class="chart-title">🔄 仓位变化</div><div id="chart3" class="chart"></div></div>
</div>

<div class="chart-container">
  <div class="chart-title">📋 各期调仓明细</div>
  <table><tr><th>#</th><th>调仓日</th><th>区间收益</th><th>净值</th><th>回撤</th><th>仓位</th><th>结果</th></tr>
{table_rows}</table>
</div>

<div class="chart-container"><div class="chart-title">📊 每期收益分布</div><div id="chart4" class="chart"></div></div>

<div class="footer">ScoreSys Backtest Report · Generated 2026-05-07 19:42</div>
</div>

<script>
var dates = ["2020-01-02", "2020-01-02", "2020-04-03", "2020-07-06", "2020-09-28", "2020-12-29", "2021-03-31", "2021-06-30", "2021-09-24", "2021-12-24", "2022-03-28", "2022-06-28", "2022-09-21", "2022-12-21", "2023-03-23", "2023-06-21", "2023-09-15", "2023-12-18", "2024-03-20", "2024-06-20", "2024-09-12", "2024-12-16", "2025-03-19", "2025-06-18", "2025-09-10", "2025-12-11"];
var values = [1.0, 0.969, 1.3568, 1.4269, 1.5034, 1.5788, 1.629, 1.8827, 1.8141, 1.7239, 1.7661, 1.6495, 1.617, 1.6512, 1.5337, 1.4298, 1.4309, 1.4702, 1.535, 1.4097, 1.7055, 1.8513, 1.8251, 2.2932, 2.3436, 2.621];
var drawdowns = [-0.0, -3.1, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -3.6, -8.4, -6.2, -12.4, -14.1, -12.3, -18.5, -21.2, -19.0, -16.8, -7.0, -14.6, -0.0, -0.0, -1.4, -0.0, -0.0, -0.0];
var positions = [100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 50, 50, 50, 25, 0, 25, 25, 25, 50, 75, 100, 100, 100, 100, 100];
var returns = [-3.1, 40.02, 5.17, 5.36, 5.01, 3.18, 15.57, -3.65, -4.97, 2.45, -6.61, -1.97, 2.11, -7.11, -6.77, 0.08, 2.75, 4.41, -8.16, 20.98, 8.55, -1.41, 25.65, 2.2, 11.84];
var icDates = ["2024-01-31", "2024-05-09", "2024-08-02", "2024-11-05", "2025-03-31"];
var icVals = [0.0793, -0.0033, -0.0669, 0.1259, 0.0226];

var chart1 = echarts.init(document.getElementById('chart1'));
chart1.setOption({
  tooltip: { trigger: 'axis', axisPointer: { type: 'cross' } },
  legend: { data: ['净值', '回撤'], textStyle: { color: '#8899a6' } },
  grid: { left: 50, right: 50, top: 40, bottom: 40 },
  xAxis: { type: 'category', data: dates, axisLabel: { color: '#8899a6', rotate: 45, fontSize: 10 } },
  yAxis: [
    { type: 'value', name: '净值', axisLabel: { color: '#8899a6' }, splitLine: { lineStyle: { color: '#22303c' } } },
    { type: 'value', name: '回撤%', axisLabel: { color: '#8899a6', formatter: '{value}%' }, splitLine: { show: false } }
  ],
  series: [
    { name: '净值', type: 'line', data: values, smooth: true,
      lineStyle: { color: '#1da1f2', width: 3 },
      areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: 'rgba(29,161,242,0.3)' }, { offset: 1, color: 'rgba(29,161,242,0)' }] } },
      itemStyle: { color: '#1da1f2' }, symbol: 'circle', symbolSize: 5 },
    { name: '回撤', type: 'bar', yAxisIndex: 1, data: drawdowns,
      itemStyle: { color: 'rgba(224,36,94,0.5)' } }
  ]
});

var chart2 = echarts.init(document.getElementById('chart2'));
chart2.setOption({
  tooltip: { trigger: 'axis', formatter: function(p){ return p[0].name + '<br>IC: ' + p[0].value.toFixed(4); } },
  grid: { left: 50, right: 20, top: 20, bottom: 40 },
  xAxis: { type: 'category', data: icDates, axisLabel: { color: '#8899a6', rotate: 30, fontSize: 10 } },
  yAxis: { type: 'value', axisLabel: { color: '#8899a6' }, splitLine: { lineStyle: { color: '#22303c' } }, min: -0.1, max: 0.15 },
  series: [{
    type: 'bar',
    data: icVals.map(function(v){ return { value: v, itemStyle: { color: v >= 0 ? '#00ba7c' : '#e0245e' } }; }),
    barWidth: '50%',
    label: { show: true, position: 'top', formatter: function(p){return p.value.toFixed(4);}, color: '#e1e8ed', fontSize: 11 },
    markLine: { silent: true, lineStyle: { color: '#666', type: 'dashed' }, data: [{ yAxis: 0 }] }
  }]
});

var chart3 = echarts.init(document.getElementById('chart3'));
chart3.setOption({
  tooltip: { trigger: 'axis' },
  grid: { left: 50, right: 20, top: 20, bottom: 40 },
  xAxis: { type: 'category', data: dates.slice(1), axisLabel: { color: '#8899a6', rotate: 45, fontSize: 9 } },
  yAxis: { type: 'value', min: 0, max: 100, axisLabel: { color: '#8899a6', formatter: '{value}%' }, splitLine: { lineStyle: { color: '#22303c' } } },
  series: [{
    type: 'bar', data: positions,
    itemStyle: { color: function(p){var v=p.value;return v===100?'#00ba7c':v>=50?'#ffd700':v>0?'#ff8c00':'#e0245e';} },
    barWidth: '60%'
  }]
});

var chart4 = echarts.init(document.getElementById('chart4'));
chart4.setOption({
  tooltip: { trigger: 'axis' },
  grid: { left: 50, right: 20, top: 20, bottom: 40 },
  xAxis: { type: 'category', data: dates.slice(1).map(function(d,i){return 'P'+(i+1);}), axisLabel: { color: '#8899a6', fontSize: 9, interval: 0, rotate: 45 } },
  yAxis: { type: 'value', axisLabel: { color: '#8899a6', formatter: '{value}%' }, splitLine: { lineStyle: { color: '#22303c' } } },
  series: [{
    type: 'bar',
    data: returns.map(function(v){return {value:v, itemStyle:{color:v>=0?'#00ba7c':'#e0245e'}};}),
    barWidth: '55%',
    markLine: { silent: true, lineStyle: { color: '#666', type: 'dashed' }, data: [{ yAxis: 0 }] }
  }]
});

window.addEventListener('resize', function(){ chart1.resize(); chart2.resize(); chart3.resize(); chart4.resize(); });
</script>
</body>
</html>
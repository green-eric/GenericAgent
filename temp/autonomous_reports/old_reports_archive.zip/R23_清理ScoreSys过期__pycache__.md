# ScoreSys __pycache__ 清理

> 自主行动 R23 | 2026-05-06 | 产出

## 清理结果

- 删除 **37** 个过期.pyc文件
- 释放 **647,048 bytes** (~632 KB)
- 涉及: backtest, calculator, config, database, data_provider, evaluator, excel_export, fetcher, main, na_analysis, result_builder, scorer, utils + tests/
- 已移除空的 __pycache__ 目录（根目录 + tests/）

# R14 - OTel LLM 调用链追踪集成

## 任务
将 `plugins/otel_trace.py` 中已有的 `llm_span` 上下文管理器集成到 `llmcore.py` 的 `MixinSession.chat()` 方法中，实现每次 LLM 调用的自动追踪。

## 变更内容
- **文件**: `llmcore.py` (MixinSession.chat 方法)
- **变更**: 16 行新增, 2 行删除
- **commit**: 38f51db

## 技术方案
由于 `chat()` 是 generator 方法（含 `yield chunk`），`with` 上下文管理器无法正确包裹（`__exit__` 在 generator 消费时才执行）。  
改用手动 `span.__enter__()` / `span.__exit__()` 模式：
1. `span.__enter__()` 在 `self.backend.ask()` 前调用，记录 input messages
2. `span.__exit__()` 在 `StopIteration` 捕获后调用，记录 output content + token usage

## 追踪字段
- `llm.input.messages` (string): 完整输入 messages JSON
- `llm.output.content` (string): 输出内容（截断 2000 字符）
- `llm.usage.input_tokens` / `output_tokens` / `total_tokens` (int): token 用量
- `llm.duration_ms` (auto): OTel 自动计算
- `llm.success` (bool): 是否成功（由 `llm_span.__exit__` 自动设置）

## 影响范围
- 所有通过 `MixinSession.chat()` 的 LLM 调用（微信 Bot / Web / CLI）自动被追踪
- 不修改任何用户项目代码
- 不影响现有功能（追踪是附加的、非阻塞的）

## 验证
- `python -c "import llmcore"` → 语法 OK ✅
- git commit 38f51db ✅
